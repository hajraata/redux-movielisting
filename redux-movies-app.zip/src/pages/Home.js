import React from "react";

import MoviesList from "../components/MoviesList";

export default function Home() {
  return (
    <>
      <MoviesList />
    </>
  );
}
